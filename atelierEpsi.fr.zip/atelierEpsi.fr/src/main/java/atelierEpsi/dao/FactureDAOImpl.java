package atelierEpsi.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

import atelierEpsi.entite.Factures;


public class FactureDAOImpl implements DAOFacture {
	
	EntityManager em;
	UserTransaction utx;

	public FactureDAOImpl(EntityManager em, UserTransaction utx) {
		this.em=em;
		this.utx=utx;
	}
	
	public void createFactures(Factures f) {
		try {
			utx.begin();
			em.persist(f);
			
			utx.commit();
		} catch (NotSupportedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SystemException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RollbackException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (HeuristicMixedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (HeuristicRollbackException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public List<Factures> getListeFactures() {
		return em.createQuery("Select f from Factures f", Factures.class).getResultList();
	}

	public Factures getFactures(Long id) {
		return em.createQuery("select f from Factures f where f.id = :id", Factures.class)
				.setParameter("id", id)
				.getSingleResult();
	}

}
