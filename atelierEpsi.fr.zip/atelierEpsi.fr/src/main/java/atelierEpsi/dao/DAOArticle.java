package atelierEpsi.dao;

import java.util.List;

import atelierEpsi.entite.Articles;

public interface DAOArticle {
	
	void createArticle(Articles a);
	
	List<Articles> getListeArticles();

}
