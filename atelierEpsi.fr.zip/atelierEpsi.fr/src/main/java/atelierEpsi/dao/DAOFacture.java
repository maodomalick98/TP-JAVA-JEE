package atelierEpsi.dao;

import java.util.List;

import atelierEpsi.entite.Factures;


public interface DAOFacture {
	
	void createFactures(Factures f);
	
	List<Factures> getListeFactures();
	
	Factures getFactures(Long id);

}
