package atelierEpsi.dao;

import java.util.List;

import atelierEpsi.entite.Clients;


public interface DAOClient {
	
	void createClient(Clients c);
	
	List<Clients> getListeClient();

}
