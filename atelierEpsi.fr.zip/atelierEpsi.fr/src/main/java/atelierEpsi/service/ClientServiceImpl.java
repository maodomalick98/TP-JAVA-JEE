package atelierEpsi.service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;

import atelierEpsi.dao.DAOClient;
import atelierEpsi.dao.DAOClientImpl;
import atelierEpsi.dto.DTOClient;
import atelierEpsi.entite.Clients;


@Stateless
@TransactionManagement(TransactionManagementType.BEAN)
public class ClientServiceImpl implements ClientService {
	@Resource
	UserTransaction utx;

	@PersistenceContext
	EntityManager em;
	
	
	public void createClient(DTOClient unClient) {
		Clients client = new Clients();
		client.setNom(unClient.getNom());
		client.setAdresse(unClient.getAdresse());
		DAOClient dao=new DAOClientImpl(em, utx);
		dao.createClient(client);
	}


	public List<Clients> getClients() {
		DAOClient dao= new DAOClientImpl(em, utx);
		return dao.getListeClient();	
		}

}
