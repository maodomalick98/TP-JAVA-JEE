package atelierEpsi.service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;

import atelierEpsi.dao.DAOFacture;
import atelierEpsi.dao.FactureDAOImpl;
import atelierEpsi.entite.Factures;

@Stateless
@TransactionManagement(TransactionManagementType.BEAN)
public class FactureServiceImpl implements FactureService {

	@PersistenceContext
	EntityManager em;
	
	@Resource
	UserTransaction utx;

	public List<Factures> getListeFactures() {
		DAOFacture dao=new FactureDAOImpl(em, utx);
		return dao.getListeFactures();	
	}

	public Factures getFacture(Long id) {
		DAOFacture dao=new FactureDAOImpl(em, utx);
		return dao.getFactures(id);
	}



}
