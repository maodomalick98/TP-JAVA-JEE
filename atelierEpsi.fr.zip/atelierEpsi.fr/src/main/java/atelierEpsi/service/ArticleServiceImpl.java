package atelierEpsi.service;

import java.util.List;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.UserTransaction;
import atelierEpsi.dao.DAOArticle;
import atelierEpsi.dao.DAOArticleImpl;
import atelierEpsi.dto.DTOArticle;
import atelierEpsi.entite.Articles;


@Stateless
@TransactionManagement(TransactionManagementType.BEAN)
public class ArticleServiceImpl implements ArticleService {

	@Resource
	UserTransaction utx;
	@PersistenceContext
	EntityManager em;
	
	public void createArticle(DTOArticle a) {
		Articles article = new Articles();
		article.setNom(a.getNom());
		article.setPrix(a.getPrix());
		DAOArticle dao=new DAOArticleImpl(em, utx);
		dao.createArticle(article);
	}
	
	public List<Articles> getArticles() {
		DAOArticle dao = new DAOArticleImpl(em, utx);
		return dao.getListeArticles();
	}
	
}
