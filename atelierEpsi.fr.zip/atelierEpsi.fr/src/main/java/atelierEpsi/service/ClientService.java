package atelierEpsi.service;

import java.util.List;

import atelierEpsi.dto.DTOClient;
import atelierEpsi.entite.Clients;


public interface ClientService {

	List<Clients> getClients();
	void createClient(DTOClient client);
}
