package atelierEpsi.service;

import java.util.List;

import atelierEpsi.entite.Factures;


public interface FactureService {
	
	/* les factures se creent en dur dans la BDD */
	/* recuperent les factures  */
	List<Factures> getListeFactures();
	/* recuperent une facture  */
	Factures getFacture(Long id);

}
