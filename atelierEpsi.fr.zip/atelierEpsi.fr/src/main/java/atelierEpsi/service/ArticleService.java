package atelierEpsi.service;

import java.util.List;

import atelierEpsi.dto.DTOArticle;
import atelierEpsi.entite.Articles;

public interface ArticleService {
	List<Articles> getArticles();
	void createArticle(DTOArticle a);
	


}
