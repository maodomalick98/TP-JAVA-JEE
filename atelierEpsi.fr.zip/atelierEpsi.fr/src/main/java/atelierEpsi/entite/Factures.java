package atelierEpsi.entite;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Factures {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	Long id;
	
	@OneToMany(mappedBy="unefacture", fetch = FetchType.EAGER)
	private List<LigneFacture> lignesFacture = new ArrayList<LigneFacture>();
	
	Date date;
	String numero;
	double prix;
	
	@ManyToOne
	@JoinColumn(name = "unClient_id")
	private Clients unClient;
	
	
	public Long getId() {
		return id;
	}
	
	public Date getDate() {
		return date;
	}
	
	public double getPrix() {
		return prix;
	}
	
	public Clients getClient() {
		return unClient;
	}
	
	public List<LigneFacture> getLignesFacture() {
		return lignesFacture;
	}
	
	public String getNumero() {
		return numero;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	
	public void setDate(Date date) {
		this.date = date;
	}
	
	public void setNumero(String numero) {
		this.numero = numero;
	}
	
	public void setPrix(double prix) {
		this.prix = prix;
	}
	
	public void setClient(Clients client) {
		this.unClient = client;
	}
	
	public void setLignesFacture(List<LigneFacture> lignesFacture) {
		this.lignesFacture = lignesFacture;
	}
}
