package atelierEpsi.entite;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Clients {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	Long id;
	
	String nom;
	
	@OneToMany(mappedBy="unClient")
	private List<Factures> factures = new ArrayList<Factures>();
	
	String adresse;
	
	public String getNom() {
		return nom;
	}
	
	public Long getId() {
		return id;
	}
	
	public String getAdresse() {
		return adresse;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public void setNom(String nom) {
		this.nom = nom;
	}
	
	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}
	
	
}
