package atelierEpsi.controller;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import atelierEpsi.dto.DTOArticle;
import atelierEpsi.service.ArticleService;


@WebServlet("/ajouterArticle")
public class AjouterArticle extends HttpServlet {
	
	@EJB
	private ArticleService service;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.getServletContext().getRequestDispatcher("/WEB-INF/pages/AjoutArticles.jsp").forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Double prix = Double.parseDouble(req.getParameter("prix"));
		DTOArticle dto = new DTOArticle();
		dto.setNom(req.getParameter("article"));
		dto.setPrix(prix);
		service.createArticle(dto);
	}
}