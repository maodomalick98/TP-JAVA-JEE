package atelierEpsi.controller;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import atelierEpsi.dto.DTOClient;
import atelierEpsi.service.ClientService;

@WebServlet("/ajouterClient")
public class AjouterClient extends HttpServlet {
	
	@EJB
	private ClientService service;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.getServletContext().getRequestDispatcher("/WEB-INF/pages/AjoutClients.jsp").forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		DTOClient dto = new DTOClient();
		dto.setNom(req.getParameter("client"));
		dto.setAdresse(req.getParameter("adresse"));
		service.createClient(dto);
	}
}