package atelierEpsi.controller;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import atelierEpsi.service.FactureService;

@WebServlet("/facturesClient")
public class FacturesClientServlet extends HttpServlet {
	
	@EJB
	private FactureService service;
	
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
	        throws ServletException, IOException
	    {
		  Long idClient = Long.parseLong(req.getParameter("idClient"));
		  req.setAttribute("factureClient", service.getFacture(idClient));
		   this.getServletContext().getRequestDispatcher("/WEB-INF/pages/facturesClient.jsp").forward(req, resp);
	    }
}
