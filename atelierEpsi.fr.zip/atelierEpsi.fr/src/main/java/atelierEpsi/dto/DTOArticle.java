package atelierEpsi.dto;

public class DTOArticle {
	
	String nom;
	double prix;
	
	
	
	public String getNom() {
		return nom;
	}
	
	
	public double getPrix() {
		return prix;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	
	public void setPrix(double prix) {
		this.prix = prix;
	}
	

}
