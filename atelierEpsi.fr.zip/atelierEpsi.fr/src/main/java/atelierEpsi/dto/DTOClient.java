package atelierEpsi.dto;

public class DTOClient {
	
	String nom;
	String adresse;
	
	
	public String getNom() {
		return nom;
	}
	
	public String getAdresse() {
		return adresse;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	
	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}
	
		
}
